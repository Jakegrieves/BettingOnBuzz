Please run in the structure

NoteBooks:

Finished Replication 
Pytrends
GoogleBuzz
GoogleBuzz Models
Monte Carlo

The File Should Also Contain

GoogleBuzzDF.csv 
players.zip (contains year-month-player GoogleTrends Data)
players 2014-2022.zip (Contains player data from 2014-2022)
Final.dta (the original Dataset made by Ramereiz et al)

notes:
1) pytrends will take forever, its just to prove it works I would not advise running as it took me two weeks to gather the data

2) there is sometimes a glitch with the GoogleBuzz notebook, to mitigate this i include GoogleBuzzDF.csv which is the data I managed to gather, so please load up this CSV file for the GoogleBuzz Models and Monte Carlo notebooks

